import { Component, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormControl, ReactiveFormsModule, Validators } from '@angular/forms';
import { YoutubeService } from '../services/youtube.service';
import { StreamDto } from '../models/stream-dto';

// Angular Material
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatTableModule } from '@angular/material/table';
import { MatCheckboxModule } from '@angular/material/checkbox';

import { HttpClientModule } from '@angular/common/http';
import { saveAs } from 'file-saver';
import { RecognitionService } from '../services/recognition.service';

@Component({
  standalone: true,
  selector: 'app-youtube-downloader',
  templateUrl: './youtube-downloader.component.html',
  styleUrls: ['./youtube-downloader.component.css'],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatSelectModule,
    MatCardModule,
    MatIconModule,
    MatListModule,
    MatProgressBarModule,
    MatTableModule,
    MatCheckboxModule,
    HttpClientModule
  ]
})
export class YoutubeDownloaderComponent implements OnDestroy {
  // Поле ввода URL
  videoUrlControl = new FormControl<string>('', [
    Validators.required,
    Validators.pattern(/^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.be)\/.+$/)
  ]);

  // Базовый набор колонок
  baseColumns: string[] = [
    'select',
    'typeIcon',
    'codec',
    'quality',
    'bitrate',
    'size'
  ];

  // Текущие колонки, которые будут отображены
  displayedColumns: string[] = [...this.baseColumns];

  streams: StreamDto[] = [];
  selectedStreams: StreamDto[] = [];
  isLoading = false;
  errorMessage = '';

  // Показывать ли колонку Language
  showLanguageColumn = false;

  // Флаги и переменные для скачивания / объединения
  downloadInProgress = false;
  isMerging = false;
  mergeResult = '';
  mergeProgress = 0;   // 0..100
  mergeStatus = '';    // "Created", "Downloading", "Merging", "Done", "Error"

  private progressInterval: any = null; // для setInterval
  private lastTaskId: string | null = null; // запоминаем taskId для скачивания

  constructor(private youtubeService: YoutubeService,
    private recognitionService:  RecognitionService) {}

  ngOnDestroy(): void {
    if (this.progressInterval) {
      clearInterval(this.progressInterval);
      this.progressInterval = null;
    }
  }

  // 1. Получить потоки
  fetchStreams() {
    if (this.videoUrlControl.invalid) {
      this.errorMessage = 'Некорректный URL.';
      return;
    }

    const videoUrl = this.videoUrlControl.value as string;
    this.isLoading = true;
    this.errorMessage = '';
    this.mergeResult = '';
    this.streams = [];
    this.selectedStreams = [];

    // Сбрасываем и флаг, и колонки (без language)
    this.showLanguageColumn = false;
    this.displayedColumns = [...this.baseColumns];
    this.mergeStatus = ''; // сброс состояния предыдущего скачивания

    this.youtubeService.getAllStreams(videoUrl).subscribe({
      next: (data) => {
        this.streams = data;
        this.isLoading = false;

        // Проверяем, есть ли хотя бы один аудиопоток с language
        const anyLanguage = this.streams.some(s => s.type === 'audio' && s.language);
        if (anyLanguage) {
          this.showLanguageColumn = true;
          if (!this.displayedColumns.includes('language')) {
            this.displayedColumns.push('language');
          }
        }
      },
      error: (error) => {
        this.errorMessage = 'Ошибка при получении потоков.';
        console.error(error);
        this.isLoading = false;
      }
    });
  }

  // 2. Работа с чекбоксами
  toggleSelection(stream: StreamDto, checked: boolean) {
    if (checked) {
      // Добавляем, если строка не задизэйблена
      if (!this.isRowDisabled(stream)) {
        this.selectedStreams.push(stream);
      }
    } else {
      // Снимаем галку
      this.removeStream(stream);

      // Если это был видеопоток, оставим только одну аудиодорожку
      const videoStillSelected = this.selectedStreams.some(s => s.type === 'video');
      if (!videoStillSelected) {
        const audios = this.selectedStreams.filter(s => s.type === 'audio');
        if (audios.length > 1) {
          const [keep] = audios; // оставим первую
          this.selectedStreams = [keep];
        }
      }
    }
  }

  isRowDisabled(stream: StreamDto): boolean {
    // Если поток уже выбран, не дизэйблим (можно снять галку)
    if (this.isStreamSelected(stream)) {
      return false;
    }

    // Если поток — видео, дизэйблим, если уже выбрано какое-то видео
    if (stream.type === 'video') {
      return this.selectedStreams.some(s => s.type === 'video');
    }

    // Если поток — аудио, смотрим логику:
    const hasVideo = this.selectedStreams.some(s => s.type === 'video');
    if (hasVideo) {
      // При выбранном видео можно выбрать много аудио
      return false;
    } else {
      // Без видео можно выбрать только 1 аудио
      const audioCount = this.selectedStreams.filter(s => s.type === 'audio').length;
      return audioCount >= 1;
    }
  }

  isStreamSelected(stream: StreamDto): boolean {
    return this.selectedStreams.includes(stream);
  }

  removeStream(stream: StreamDto) {
    const index = this.selectedStreams.indexOf(stream);
    if (index > -1) {
      this.selectedStreams.splice(index, 1);
    }
  }

  // 3. "Объединить" (старая кнопка "Скачай")
  mergeSelectedStreams() {
    const video = this.selectedStreams.find(s => s.type === 'video');
    const audios = this.selectedStreams.filter(s => s.type === 'audio');

    // Либо видео + (0..N) аудио, либо ровно одна аудио, если видео нет
    if (!video && audios.length !== 1) {
      this.errorMessage = 'Можно выбрать либо 1 видео (с любым количеством аудио), либо одну аудио-дорожку без видео.';
      return;
    }

    this.errorMessage = '';
    this.mergeResult = '';
    this.isMerging = true;
    this.mergeProgress = 0;
    this.mergeStatus = '';
    this.lastTaskId = null;

    const videoUrl = this.videoUrlControl.value as string;
    const videoQualityLabel = this.getVideoQualityLabel(video?.qualityLabel);
    const container = video ? (video.container ?? 'mp4') : 'mp3';

    this.youtubeService.mergeVideoAndAudios(
      videoUrl,
      videoQualityLabel,
      container,
      audios
    ).subscribe({
      next: (resp) => {
        if (!resp || !resp.taskId) {
          this.errorMessage = 'Не удалось получить taskId от сервера.';
          this.isMerging = false;
          return;
        }
        const taskId = resp.taskId;
        this.lastTaskId = taskId;
        this.pollProgress(taskId);
      },
      error: (err) => {
        console.error(err);
        this.errorMessage = 'Ошибка при запуске объединения.';
        this.isMerging = false;
      }
    });
  }

  pollProgress(taskId: string) {
    if (this.progressInterval) {
      clearInterval(this.progressInterval);
    }

    this.progressInterval = setInterval(() => {
      this.youtubeService.getProgress(taskId).subscribe({
        next: (statusResp) => {
          this.mergeStatus = statusResp.status;
          this.mergeProgress = statusResp.progress;
          if (statusResp.error) {
            this.errorMessage = statusResp.error;
          }

          // Завершение
          if (this.mergeProgress >= 100 || this.mergeStatus === 'Done') {
            clearInterval(this.progressInterval);
            this.progressInterval = null;
            this.isMerging = false;
            this.mergeResult = `Задача завершена: ${this.mergeStatus}. Прогресс = ${this.mergeProgress}%`;
          }
          if (this.mergeStatus === 'Error') {
            clearInterval(this.progressInterval);
            this.progressInterval = null;
            this.isMerging = false;
            this.mergeResult = `Ошибка. Статус: Error. ${this.errorMessage}`;
          }
        },
        error: (err) => {
          console.error('Ошибка при запросе прогресса:', err);
        }
      });
    }, 3000);
  }

  // 4. Скачать итоговый файл (если mergeStatus = 'Done')
  downloadMergedFile() {
    if (!this.lastTaskId) {
      this.errorMessage = 'Нет taskId для скачивания результата.';
      return;
    }
    this.youtubeService.downloadMergedResult(this.lastTaskId).subscribe({
      next: (blob) => {
        const fileName = `merged_${this.lastTaskId}.mp4`;
        saveAs(blob, fileName);
      },
      error: (err) => {
        console.error(err);
        this.errorMessage = `Ошибка при скачивании результата: ${err.message}`;
      }
    });
  }

  downloadMergedFile1() {
   
    const videoUrl = this.videoUrlControl.value as string;
    this.recognitionService.startSubtitleRecognition(videoUrl).subscribe();


  }

  // Вспомогательные методы
  getTypeIcon(stream: StreamDto): string {
    return stream.type === 'video' ? 'videocam' : 'music_note';
  }

  getVideoQualityLabel(qualityLabel: any): string | null {
    if (!qualityLabel) return null;
    if (typeof qualityLabel === 'object' && qualityLabel.label) {
      return qualityLabel.label;
    }
    if (typeof qualityLabel === 'string') {
      return qualityLabel;
    }
    return null;
  }
}