import { Pipe, PipeTransform } from '@angular/core';
import { DatePipe } from '@angular/common';

@Pipe({
  name: 'localTime'
})
export class LocalTimePipe implements PipeTransform {
  transform(value: any, format: string = 'yyyy-MM-dd HH:mm:ss'): string | null {
    if (!value) {
      return null;
    }
    
    let date: Date;
    
    if (typeof value === 'string') {
      // Если строка не содержит символа 'T', заменяем первый пробел на 'T'
      let isoValue = value;
      if (!isoValue.includes('T')) {
        isoValue = isoValue.replace(' ', 'T');
      }
      // Если отсутствует информация о часовом поясе (нет 'Z' и знака '+'), добавляем 'Z', чтобы указать, что время в UTC
      if (!isoValue.endsWith('Z') && isoValue.indexOf('+') === -1) {
        isoValue += 'Z';
      }
      date = new Date(isoValue);
    } else {
      date = new Date(value);
    }
    
    // DatePipe по умолчанию выводит дату с учетом локального часового пояса
    return new DatePipe('en-US').transform(date, format);
  }
}
